#include "mt19937ar.c"
#include <iostream>
#include <time.h>
#include <sys/time.h>
#include <cmath>

using namespace std;

double getRandomNumberInRange(double start, double end){
    return start + (genrand_real2()*(end-start));
}

double segundos_transcurridos(struct timeval *a, struct timeval *b)
{
  return
    (double)(a->tv_sec + (double)a->tv_usec/1000000) -
    (double)(b->tv_sec + (double)b->tv_usec/1000000);
}

int main()
{
    init_genrand(time(NULL));

    int n;

    cout << "Ingrese la cantidad de iteraciones\n";
    cin >> n;
    cout << "La cantidad de iteraciones es " << n << "\n";

    struct timeval start, end;

    gettimeofday(&start, NULL);;
    
    double X = 0;
    double V = 0;

    for(int i=0;i<n;i++){
        double t1 = getRandomNumberInRange(32,48);
        double t2 = getRandomNumberInRange(40,60);
        double t3 = getRandomNumberInRange(15,25);
        double t5 = getRandomNumberInRange(10,15);
        double t7 = getRandomNumberInRange(18,24);
        double t8 = getRandomNumberInRange(4,8);

        double tiempoFinal = t1+t2+t3+t5+t7+t8;

        X += tiempoFinal;
        V += tiempoFinal*tiempoFinal;

    }

    X=X/n;
    V=V/(n*(n-1))-X*X/(n-1);

    gettimeofday(&end, NULL);

    cout << "X = " << X << "\n";
    cout << "Varianza = " << V << "\n";
    cout << "Desviación Estándar = " << sqrt(V) << "\n";

    double secs = segundos_transcurridos(&end, &start); //Calcular segundos

    //Calculo del tiempo insumido
    cout << "Tiempo= " << secs << " segundos\n";

    return 0;
}

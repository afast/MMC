#!/bin/sh
echo 10 | ./main
echo 100 | ./main
echo 1000 | ./main
echo 10000 | ./main

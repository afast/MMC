#!/bin/sh
g++ obligatorio.cpp -o main

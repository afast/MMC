#!/bin/sh
echo 1929229682 | ./main

#!/bin/sh
echo 1000000 | ./main

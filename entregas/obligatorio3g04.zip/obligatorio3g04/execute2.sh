#!/bin/sh
echo 151805617 | ./main
